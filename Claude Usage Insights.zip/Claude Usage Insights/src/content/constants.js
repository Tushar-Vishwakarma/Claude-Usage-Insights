(() => {
	'use strict';

	const CC = (globalThis.ClaudeCounter = globalThis.ClaudeCounter || {});

	CC.LINKS = Object.freeze({
		permanent: {
			label: '▶ Watch Artificial Popcorn',
			url: 'https://www.youtube.com/@ArtificialPopcorn?sub_confirmation=1'
		},
		optional: [
			{
				id: 'linkedin',
				label: 'LinkedIn',
				url: 'https://www.linkedin.com/in/tusharvishwakarma/',
				defaultChecked: false
			},
			{
				id: 'topmate',
				label: 'Topmate (1:1 bookings)',
				url: 'https://topmate.io/tushar_vishwakarma',
				defaultChecked: false
			},
			{
				id: 'books',
				label: 'Books',
				defaultChecked: false,
				subLinks: [
					{
						label: 'BhaiLang',
						url: 'https://www.amazon.in/BhaiLang-programming-language-written-Typescript-ebook/dp/B09W1FRQWY'
					},
					{
						label: 'Fundamental Notes on Digital Marketing',
						url: 'https://www.flipkart.com/fundamental-notes-digital-marketing-tushar-vishwakarma/p/itm312562a7dd97c'
					},
					{
						label: 'My Heart Beat',
						url: 'https://www.amazon.in/My-Heart-Beat-Tushar-Vishwakarma-ebook/dp/B00A1ERRWY'
					}
				]
			}
		]
	});

	CC.DOM = Object.freeze({
		CHAT_MENU_TRIGGER: '[data-testid="chat-menu-trigger"]',
		MODEL_SELECTOR_DROPDOWN: '[data-testid="model-selector-dropdown"]',
		CHAT_PROJECT_WRAPPER: '.chat-project-wrapper',
		SIDEBAR_CONTAINER: 'nav, [data-testid="sidebar"], aside',
		BRIDGE_SCRIPT_ID: 'cc-bridge-script'
	});

	CC.CONST = Object.freeze({
		CACHE_WINDOW_MS: 5 * 60 * 1000,
		CONTEXT_LIMIT_TOKENS: 200000,
		USAGE_HISTORY_KEY: 'claude_counter_usage_history',
		USAGE_HISTORY_MAX_DAYS: 30,
		SAVED_MODEL_KEY: 'claude_counter_selected_model',
		SEEN_WELCOME_TOOLTIP_KEY: 'claude_counter_seen_welcome_tooltip',
		LINKS_PREFS_KEY: 'claude_counter_links_prefs',
		SIDEBAR_COLLAPSED_KEY: 'claude_counter_sidebar_collapsed'
	});

	/**
	 * Pricing configuration in USD per million tokens (API-equivalent rates).
	 * Ratios: Blended fallback ratio (e.g. 30% prompt input / 70% completion output)
	 * is used when exact input vs output token breakdown is not known.
	 */
	CC.PRICING = Object.freeze({
		currency: '$',
		defaultModel: 'claude-3-7-sonnet',
		// Default assumption for general interactive chat usage
		defaultBlendedRatio: {
			input: 0.3,
			output: 0.7
		},
		models: Object.freeze({
			'claude-3-7-sonnet': {
				label: 'Claude 3.7 Sonnet',
				inputPerMillion: 3.0,
				outputPerMillion: 15.0
			},
			'claude-3-5-sonnet': {
				label: 'Claude 3.5 Sonnet',
				inputPerMillion: 3.0,
				outputPerMillion: 15.0
			},
			'claude-3-5-haiku': {
				label: 'Claude 3.5 Haiku',
				inputPerMillion: 0.8,
				outputPerMillion: 4.0
			},
			'claude-3-opus': {
				label: 'Claude 3 Opus',
				inputPerMillion: 15.0,
				outputPerMillion: 75.0
			}
		})
	});

	CC.COLORS = Object.freeze({
		PROGRESS_FILL_DARK: '#2c84db',
		PROGRESS_FILL_LIGHT: '#5aa6ff',
		PROGRESS_OUTLINE_DARK: '#787877',
		PROGRESS_OUTLINE_LIGHT: '#bfbfbf',
		PROGRESS_MARKER_DARK: '#ffffff',
		PROGRESS_MARKER_LIGHT: '#111111',
		RED_WARNING: '#ce2029',
		BOLD_LIGHT: '#141413',
		BOLD_DARK: '#faf9f5'
	});
})();

// Creator: Tushar Vishwakarma
