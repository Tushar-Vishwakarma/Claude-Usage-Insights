(() => {
	'use strict';

	const CC = (globalThis.ClaudeCounter = globalThis.ClaudeCounter || {});

	function formatSeconds(totalSeconds) {
		const minutes = Math.floor(totalSeconds / 60);
		const seconds = totalSeconds % 60;
		return `${minutes}:${String(seconds).padStart(2, '0')}`;
	}

	function formatResetCountdown(timestampMs) {
		const diffMs = timestampMs - Date.now();
		if (diffMs <= 0) return '0m';

		const totalMinutes = Math.round(diffMs / (1000 * 60));
		if (totalMinutes < 60) return `${totalMinutes}m`;

		const hours = Math.floor(totalMinutes / 60);
		const minutes = totalMinutes % 60;
		if (hours < 24) return `${hours}h ${minutes}m`;

		const days = Math.floor(hours / 24);
		const remHours = hours % 24;
		return `${days}d ${remHours}h`;
	}

	function setupTooltip(element, tooltip, { topOffset = 10 } = {}) {
		if (!element || !tooltip) return;
		if (element.hasAttribute('data-tooltip-setup')) return;
		element.setAttribute('data-tooltip-setup', 'true');
		element.classList.add('cc-tooltipTrigger');

		let pressTimer;
		let hideTimer;

		const show = () => {
			const rect = element.getBoundingClientRect();
			tooltip.style.opacity = '1';
			const tipRect = tooltip.getBoundingClientRect();

			let left = rect.left + rect.width / 2;
			if (left + tipRect.width / 2 > window.innerWidth) left = window.innerWidth - tipRect.width / 2 - 10;
			if (left - tipRect.width / 2 < 0) left = tipRect.width / 2 + 10;

			let top = rect.top - tipRect.height - topOffset;
			if (top < 10) top = rect.bottom + 10;

			tooltip.style.left = `${left}px`;
			tooltip.style.top = `${top}px`;
			tooltip.style.transform = 'translateX(-50%)';
		};

		const hide = () => {
			tooltip.style.opacity = '0';
			clearTimeout(hideTimer);
		};

		element.addEventListener('pointerdown', (e) => {
			if (e.pointerType === 'touch' || e.pointerType === 'pen') {
				pressTimer = setTimeout(() => {
					show();
					hideTimer = setTimeout(hide, 3000);
				}, 500);
			}
		});

		element.addEventListener('pointerup', () => clearTimeout(pressTimer));
		element.addEventListener('pointercancel', () => {
			clearTimeout(pressTimer);
			hide();
		});

		element.addEventListener('pointerenter', (e) => {
			if (e.pointerType === 'mouse') show();
		});

		element.addEventListener('pointerleave', (e) => {
			if (e.pointerType === 'mouse') hide();
		});
	}

	function makeTooltip(text) {
		const tip = document.createElement('div');
		tip.className = 'bg-bg-500 text-text-000 cc-tooltip';
		tip.textContent = text;
		document.body.appendChild(tip);
		return tip;
	}

	class CounterUI {
		constructor({ onUsageRefresh } = {}) {
			this.onUsageRefresh = onUsageRefresh || null;

			this.headerContainer = null;
			this.headerDisplay = null;
			this.lengthGroup = null;
			this.lengthDisplay = null;
			this.cachedDisplay = null;
			this.lengthBar = null;
			this.lengthTooltip = null;
			this.lastCachedUntilMs = null;
			this.pendingCache = false;

			this.sessionResetMs = null;
			this.weeklyResetMs = null;
			this.sessionWindowStartMs = null;
			this.weeklyWindowStartMs = null;
			this.refreshingUsage = false;

			this.domObserver = null;

			// Current metrics tracking for snapshots
			this.currentTotalTokens = null;
			this.currentInputTokens = null;
			this.currentOutputTokens = null;
			this.currentSessionPercent = null;
			this.currentWeeklyPercent = null;

			// Model selection & pricing
			this.selectedModel = this._loadSelectedModel();

			// Links, Settings & Dashboard UI
			this.linksContainer = null;
			this.permanentLink = null;
			this.optionalLinksSpan = null;
			this.dashboardButton = null;
			this.dashboardModal = null;
			this.welcomeTooltipEl = null;
			this.welcomeTooltipTimer = null;
			this.sidebarSection = null;
			this.sidebarLinksList = null;
			this.settingsButton = null;
			this.settingsModal = null;
			this.savedPreferences = this._loadPreferences();
			this.isSidebarCollapsed = this._loadSidebarCollapsed();

			// Sidebar usage bars
			this.sidebarSessionStat = null;
			this.sidebarSessionBarFill = null;
			this.sidebarWeeklyStat = null;
			this.sidebarWeeklyBarFill = null;

			this.dashboardDays = 7;
			this.dashboardMetric = 'session'; // 'session' | 'tokens' | 'cost'
		}

		_loadSidebarCollapsed() {
			try {
				const key = CC.CONST.SIDEBAR_COLLAPSED_KEY || 'claude_counter_sidebar_collapsed';
				return localStorage.getItem(key) === 'true';
			} catch {
				return false;
			}
		}

		_saveSidebarCollapsed(collapsed) {
			this.isSidebarCollapsed = collapsed;
			try {
				const key = CC.CONST.SIDEBAR_COLLAPSED_KEY || 'claude_counter_sidebar_collapsed';
				localStorage.setItem(key, String(collapsed));
			} catch {
				// ignore
			}
		}

		_loadSelectedModel() {
			try {
				const saved = localStorage.getItem(CC.CONST.SAVED_MODEL_KEY);
				if (saved && CC.PRICING?.models?.[saved]) return saved;
			} catch {
				// ignore
			}
			return CC.PRICING?.defaultModel || 'claude-3-7-sonnet';
		}

		_saveSelectedModel(modelKey) {
			this.selectedModel = modelKey;
			try {
				localStorage.setItem(CC.CONST.SAVED_MODEL_KEY, modelKey);
			} catch {
				// ignore
			}
		}

		_detectActiveModel() {
			// Try to read active model name from Claude's model selector button in the DOM
			try {
				const selectorBtn = document.querySelector(CC.DOM.MODEL_SELECTOR_DROPDOWN);
				if (selectorBtn) {
					const text = (selectorBtn.textContent || '').toLowerCase();
					if (text.includes('3.7') && text.includes('sonnet')) return 'claude-3-7-sonnet';
					if (text.includes('3.5') && text.includes('sonnet')) return 'claude-3-5-sonnet';
					if (text.includes('haiku')) return 'claude-3-5-haiku';
					if (text.includes('opus')) return 'claude-3-opus';
					if (text.includes('sonnet')) return 'claude-3-7-sonnet';
				}
			} catch {
				// ignore
			}
			return null;
		}

		_calculateCost({ totalTokens, inputTokens, outputTokens, modelKey } = {}) {
			const mKey = modelKey || this.selectedModel || CC.PRICING?.defaultModel || 'claude-3-7-sonnet';
			const pricing = CC.PRICING?.models?.[mKey] || CC.PRICING?.models?.['claude-3-7-sonnet'] || {
				inputPerMillion: 3.0,
				outputPerMillion: 15.0
			};

			let inTokens = 0;
			let outTokens = 0;

			if (typeof inputTokens === 'number' && typeof outputTokens === 'number') {
				inTokens = inputTokens;
				outTokens = outputTokens;
			} else if (typeof totalTokens === 'number') {
				const ratio = CC.PRICING?.defaultBlendedRatio || { input: 0.3, output: 0.7 };
				inTokens = totalTokens * ratio.input;
				outTokens = totalTokens * ratio.output;
			}

			const inCost = (inTokens / 1_000_000) * pricing.inputPerMillion;
			const outCost = (outTokens / 1_000_000) * pricing.outputPerMillion;
			return inCost + outCost;
		}

		_loadHistory() {
			try {
				const raw = localStorage.getItem(CC.CONST.USAGE_HISTORY_KEY);
				if (raw) {
					const list = JSON.parse(raw);
					if (Array.isArray(list)) return list;
				}
			} catch {
				// ignore localStorage errors
			}
			return [];
		}

		_saveHistory(history) {
			try {
				localStorage.setItem(CC.CONST.USAGE_HISTORY_KEY, JSON.stringify(history));
			} catch {
				// ignore localStorage errors
			}
		}

		_clearUsageHistory() {
			try {
				localStorage.removeItem(CC.CONST.USAGE_HISTORY_KEY);
			} catch {
				// ignore localStorage errors
			}
		}

		recordSnapshot({ sessionPercent, weeklyPercent, tokenCount, inputTokens, outputTokens } = {}) {
			if (typeof sessionPercent === 'number') this.currentSessionPercent = sessionPercent;
			if (typeof weeklyPercent === 'number') this.currentWeeklyPercent = weeklyPercent;
			if (typeof tokenCount === 'number') this.currentTotalTokens = tokenCount;
			if (typeof inputTokens === 'number') this.currentInputTokens = inputTokens;
			if (typeof outputTokens === 'number') this.currentOutputTokens = outputTokens;

			const sPct = this.currentSessionPercent ?? null;
			const wPct = this.currentWeeklyPercent ?? null;
			const tCnt = this.currentTotalTokens ?? null;
			const inCnt = this.currentInputTokens ?? null;
			const outCnt = this.currentOutputTokens ?? null;

			if (sPct === null && wPct === null && tCnt === null) return;

			const now = Date.now();
			const history = this._loadHistory();

			// Throttling: if last snapshot is less than 60 seconds old, update it in place instead of creating duplicates
			const last = history[history.length - 1];
			if (last && now - last.timestamp < 60 * 1000) {
				last.timestamp = now;
				if (sPct !== null) last.sessionPercent = sPct;
				if (wPct !== null) last.weeklyPercent = wPct;
				if (tCnt !== null) last.tokenCount = tCnt;
				if (inCnt !== null) last.inputTokens = inCnt;
				if (outCnt !== null) last.outputTokens = outCnt;
			} else {
				history.push({
					timestamp: now,
					sessionPercent: sPct !== null ? Math.round(sPct * 10) / 10 : null,
					weeklyPercent: wPct !== null ? Math.round(wPct * 10) / 10 : null,
					tokenCount: tCnt !== null ? Math.round(tCnt) : null,
					inputTokens: inCnt !== null ? Math.round(inCnt) : null,
					outputTokens: outCnt !== null ? Math.round(outCnt) : null
				});
			}

			// Prune entries older than 30 days
			const cutoff = now - (CC.CONST.USAGE_HISTORY_MAX_DAYS || 30) * 24 * 60 * 60 * 1000;
			const pruned = history.filter((entry) => entry && entry.timestamp && entry.timestamp >= cutoff);
			this._saveHistory(pruned);
		}

		_loadPreferences() {
			try {
				const key = CC.CONST.LINKS_PREFS_KEY || 'claude_counter_links_prefs';
				const saved = localStorage.getItem(key);
				if (saved) return JSON.parse(saved);
			} catch {
				// ignore localStorage errors
			}
			const defaults = {};
			if (CC.LINKS?.optional) {
				for (const item of CC.LINKS.optional) {
					defaults[item.id] = !!item.defaultChecked;
				}
			}
			return defaults;
		}

		_savePreferences(prefs) {
			this.savedPreferences = prefs;
			try {
				const key = CC.CONST.LINKS_PREFS_KEY || 'claude_counter_links_prefs';
				localStorage.setItem(key, JSON.stringify(prefs));
			} catch {
				// ignore localStorage errors
			}
			this._renderOptionalLinks();
			this._renderSidebarLinks();
		}

		getProgressChrome() {
			const root = document.documentElement;
			const modeDark = root.dataset?.mode === 'dark';
			const modeLight = root.dataset?.mode === 'light';
			const isDark = modeDark && !modeLight;

			return {
				strokeColor: isDark ? CC.COLORS.PROGRESS_OUTLINE_DARK : CC.COLORS.PROGRESS_OUTLINE_LIGHT,
				fillColor: isDark ? CC.COLORS.PROGRESS_FILL_DARK : CC.COLORS.PROGRESS_FILL_LIGHT,
				markerColor: isDark ? CC.COLORS.PROGRESS_MARKER_DARK : CC.COLORS.PROGRESS_MARKER_LIGHT,
				boldColor: isDark ? CC.COLORS.BOLD_DARK : CC.COLORS.BOLD_LIGHT
			};
		}

		refreshProgressChrome() {
			const { strokeColor, fillColor, markerColor } = this.getProgressChrome();

			const applyBarChrome = (bar, { fillWarn } = {}) => {
				if (!bar) return;
				bar.style.setProperty('--cc-stroke', strokeColor);
				bar.style.setProperty('--cc-fill', fillColor);
				bar.style.setProperty('--cc-fill-warn', fillWarn ?? fillColor);
				bar.style.setProperty('--cc-marker', markerColor);
			};

			applyBarChrome(this.lengthBar, { fillWarn: fillColor });
			applyBarChrome(this.sidebarSessionBarFill?.parentElement, { fillWarn: CC.COLORS.RED_WARNING });
			applyBarChrome(this.sidebarWeeklyBarFill?.parentElement, { fillWarn: CC.COLORS.RED_WARNING });
		}

		initialize() {
			// Header container (tokens + cache timer)
			this.headerContainer = document.createElement('div');
			this.headerContainer.className = 'text-text-500 text-xs !px-1 cc-header';

			this.headerDisplay = document.createElement('span');
			this.headerDisplay.className = 'cc-headerItem';

			this.lengthGroup = document.createElement('span');
			this.lengthDisplay = document.createElement('span');
			this.cachedDisplay = document.createElement('span');
			this.cacheTimeSpan = null; // reference to inner time span

			this.lengthGroup.appendChild(this.lengthDisplay);
			this.headerDisplay.appendChild(this.lengthGroup);

			// Links container (permanent YouTube + optional links + settings button)
			this._initLinksUI();

			// Sidebar Section (Dedicated entry)
			this._initSidebarUI();

			this._setupTooltips();
			this._observeDom();
			this._observeTheme();
		}

		_initLinksUI() {
			this.linksContainer = document.createElement('span');
			this.linksContainer.className = 'cc-linksContainer inline-flex items-center gap-1.5';

			// Permanent YouTube Link (Clean compact header version)
			if (CC.LINKS?.permanent) {
				const perm = CC.LINKS.permanent;
				this.permanentLink = document.createElement('a');
				this.permanentLink.href = perm.url;
				this.permanentLink.target = '_blank';
				this.permanentLink.rel = 'noopener noreferrer';
				this.permanentLink.className = 'cc-link cc-link--permanent';
				this.permanentLink.textContent = perm.label;
				this.linksContainer.appendChild(this.permanentLink);
			}

			// Optional Links Span
			this.optionalLinksSpan = document.createElement('span');
			this.optionalLinksSpan.className = 'cc-optionalLinks inline-flex items-center gap-1.5';
			this.linksContainer.appendChild(this.optionalLinksSpan);
			this._renderOptionalLinks();

			// Dashboard Trigger Button (Chart icon)
			this.dashboardButton = document.createElement('button');
			this.dashboardButton.type = 'button';
			this.dashboardButton.className = 'cc-settingsBtn cc-dashboardBtn inline-flex items-center justify-center';
			this.dashboardButton.setAttribute('aria-label', 'Usage Analytics Dashboard');
			this.dashboardButton.title = 'Usage Analytics';
			this.dashboardButton.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>`;

			this.dashboardButton.addEventListener('click', (e) => {
				e.stopPropagation();
				this._toggleDashboardModal();
			});

			this.linksContainer.appendChild(this.dashboardButton);

			// Settings Trigger Button (Gear icon)
			this.settingsButton = document.createElement('button');
			this.settingsButton.type = 'button';
			this.settingsButton.className = 'cc-settingsBtn inline-flex items-center justify-center';
			this.settingsButton.setAttribute('aria-label', 'Claude Usage Insights Settings');
			this.settingsButton.title = 'Settings';
			this.settingsButton.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>`;

			this.settingsButton.addEventListener('click', (e) => {
				e.stopPropagation();
				this._toggleSettingsModal(this.settingsButton);
			});

			this.linksContainer.appendChild(this.settingsButton);
		}

		_renderOptionalLinks() {
			if (!this.optionalLinksSpan) return;
			this.optionalLinksSpan.replaceChildren();

			if (!CC.LINKS?.optional) return;

			for (const item of CC.LINKS.optional) {
				const isChecked = !!this.savedPreferences[item.id];
				if (!isChecked) continue;

				if (item.subLinks && Array.isArray(item.subLinks)) {
					const groupSpan = document.createElement('span');
					groupSpan.className = 'cc-linkGroup inline-flex items-center gap-1';
					const labelSpan = document.createElement('span');
					labelSpan.className = 'cc-linkGroup__label';
					labelSpan.textContent = `${item.label}:`;
					groupSpan.appendChild(labelSpan);

					item.subLinks.forEach((sub, idx) => {
						const link = document.createElement('a');
						link.href = sub.url;
						link.target = '_blank';
						link.rel = 'noopener noreferrer';
						link.className = 'cc-link cc-link--sub';
						link.textContent = sub.label;
						groupSpan.appendChild(link);
						if (idx < item.subLinks.length - 1) {
							const sep = document.createElement('span');
							sep.className = 'cc-linkSep';
							sep.textContent = '·';
							groupSpan.appendChild(sep);
						}
					});
					this.optionalLinksSpan.appendChild(groupSpan);
				} else {
					const link = document.createElement('a');
					link.href = item.url;
					link.target = '_blank';
					link.rel = 'noopener noreferrer';
					link.className = 'cc-link cc-link--optional';
					link.textContent = item.label;
					this.optionalLinksSpan.appendChild(link);
				}
			}
		}

		_initSidebarUI() {
			this.sidebarSection = document.createElement('div');
			this.sidebarSection.className = `cc-sidebarSection ${this.isSidebarCollapsed ? 'is-collapsed' : ''}`;

			const header = document.createElement('div');
			header.className = 'cc-sidebarSection__header';

			const titleGroup = document.createElement('div');
			titleGroup.className = 'cc-sidebarSection__titleGroup';

			const chevron = document.createElement('span');
			chevron.className = 'cc-sidebarSection__chevron';
			chevron.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>`;

			const title = document.createElement('span');
			title.className = 'cc-sidebarSection__title';
			title.textContent = 'Usage';

			titleGroup.appendChild(chevron);
			titleGroup.appendChild(title);

			const actions = document.createElement('div');
			actions.className = 'cc-sidebarSection__actions';

			const dashBtn = document.createElement('button');
			dashBtn.type = 'button';
			dashBtn.className = 'cc-sidebarSection__btn';
			dashBtn.title = 'Usage Analytics';
			dashBtn.setAttribute('aria-label', 'Usage Analytics');
			dashBtn.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>`;
			dashBtn.addEventListener('click', (e) => {
				e.stopPropagation();
				this._toggleDashboardModal(dashBtn);
			});

			const settBtn = document.createElement('button');
			settBtn.type = 'button';
			settBtn.className = 'cc-sidebarSection__btn';
			settBtn.title = 'Settings';
			settBtn.setAttribute('aria-label', 'Settings');
			settBtn.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>`;
			settBtn.addEventListener('click', (e) => {
				e.stopPropagation();
				this._toggleSettingsModal(settBtn);
			});

			actions.appendChild(dashBtn);
			actions.appendChild(settBtn);

			header.appendChild(titleGroup);
			header.appendChild(actions);

			// Click header to collapse / expand (like Claude's Chats / Projects sections)
			header.addEventListener('click', () => {
				const nextState = !this.sidebarSection.classList.contains('is-collapsed');
				this.sidebarSection.classList.toggle('is-collapsed', nextState);
				this._saveSidebarCollapsed(nextState);
			});

			this.sidebarSection.appendChild(header);

			this.sidebarLinksList = document.createElement('div');
			this.sidebarLinksList.className = 'cc-sidebarSection__links';
			this.sidebarSection.appendChild(this.sidebarLinksList);
			this._renderSidebarLinks();
		}

		_renderSidebarLinks() {
			if (!this.sidebarLinksList) return;
			this.sidebarLinksList.replaceChildren();

			// 1. Permanent item 1: Watch Artificial Popcorn (in blue)
			if (CC.LINKS?.permanent) {
				const perm = document.createElement('a');
				perm.href = CC.LINKS.permanent.url;
				perm.target = '_blank';
				perm.rel = 'noopener noreferrer';
				perm.className = 'cc-sidebarSection__link cc-sidebarSection__link--permanent';
				perm.innerHTML = `<span>▶</span> <span>Watch Artificial Popcorn</span>`;
				this.sidebarLinksList.appendChild(perm);
			}

			// 2. Session (5h) Progress Bar Box
			const sessionCard = document.createElement('div');
			sessionCard.className = 'cc-sidebarUsage';
			const sessionTop = document.createElement('div');
			sessionTop.className = 'cc-sidebarUsage__top';
			const sessionLabel = document.createElement('span');
			sessionLabel.className = 'cc-sidebarUsage__label';
			sessionLabel.textContent = 'Session (5h)';
			this.sidebarSessionStat = document.createElement('span');
			this.sidebarSessionStat.className = 'cc-sidebarUsage__stat';
			this.sidebarSessionStat.textContent = this.currentSessionPercent != null ? `${Math.round(this.currentSessionPercent * 10) / 10}%` : '0%';
			sessionTop.appendChild(sessionLabel);
			sessionTop.appendChild(this.sidebarSessionStat);

			const sessionBar = document.createElement('div');
			sessionBar.className = 'cc-bar cc-bar--sidebar';
			this.sidebarSessionBarFill = document.createElement('div');
			this.sidebarSessionBarFill.className = 'cc-bar__fill cc-bar__fill--red';
			this.sidebarSessionBarFill.style.width = `${Math.max(0, Math.min(100, this.currentSessionPercent || 0))}%`;
			sessionBar.appendChild(this.sidebarSessionBarFill);
			sessionCard.appendChild(sessionTop);
			sessionCard.appendChild(sessionBar);
			this.sidebarLinksList.appendChild(sessionCard);

			// 3. Weekly Progress Bar Box
			const weeklyCard = document.createElement('div');
			weeklyCard.className = 'cc-sidebarUsage';
			const weeklyTop = document.createElement('div');
			weeklyTop.className = 'cc-sidebarUsage__top';
			const weeklyLabel = document.createElement('span');
			weeklyLabel.className = 'cc-sidebarUsage__label';
			weeklyLabel.textContent = 'Weekly (7d)';
			this.sidebarWeeklyStat = document.createElement('span');
			this.sidebarWeeklyStat.className = 'cc-sidebarUsage__stat';
			this.sidebarWeeklyStat.textContent = this.currentWeeklyPercent != null ? `${Math.round(this.currentWeeklyPercent * 10) / 10}%` : '0%';
			weeklyTop.appendChild(weeklyLabel);
			weeklyTop.appendChild(this.sidebarWeeklyStat);

			const weeklyBar = document.createElement('div');
			weeklyBar.className = 'cc-bar cc-bar--sidebar';
			this.sidebarWeeklyBarFill = document.createElement('div');
			this.sidebarWeeklyBarFill.className = 'cc-bar__fill cc-bar__fill--red';
			this.sidebarWeeklyBarFill.style.width = `${Math.max(0, Math.min(100, this.currentWeeklyPercent || 0))}%`;
			weeklyBar.appendChild(this.sidebarWeeklyBarFill);
			weeklyCard.appendChild(weeklyTop);
			weeklyCard.appendChild(weeklyBar);
			this.sidebarLinksList.appendChild(weeklyCard);

			// 4. Permanent item 4: Usage Analytics
			const analyticsRow = document.createElement('button');
			analyticsRow.type = 'button';
			analyticsRow.className = 'cc-sidebarSection__link cc-sidebarSection__link--analytics';
			analyticsRow.innerHTML = `<span style="display:inline-flex;align-items:center;"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg></span> <span>Usage Analytics</span>`;
			analyticsRow.addEventListener('click', (e) => {
				e.stopPropagation();
				this._toggleDashboardModal(analyticsRow);
			});
			this.sidebarLinksList.appendChild(analyticsRow);

			// Show optional links ONLY when checked in settings
			if (CC.LINKS?.optional) {
				for (const item of CC.LINKS.optional) {
					const isChecked = !!this.savedPreferences[item.id];
					if (!isChecked) continue;

					if (item.subLinks && Array.isArray(item.subLinks)) {
						item.subLinks.forEach((sub) => {
							const l = document.createElement('a');
							l.href = sub.url;
							l.target = '_blank';
							l.rel = 'noopener noreferrer';
							l.className = 'cc-sidebarSection__link';
							l.innerHTML = `<span>📚</span> <span>${sub.label}</span>`;
							this.sidebarLinksList.appendChild(l);
						});
					} else {
						const icon = item.id === 'linkedin' ? '💼' : item.id === 'topmate' ? '🤝' : '🔗';
						const l = document.createElement('a');
						l.href = item.url;
						l.target = '_blank';
						l.rel = 'noopener noreferrer';
						l.className = 'cc-sidebarSection__link';
						l.innerHTML = `<span>${icon}</span> <span>${item.label}</span>`;
						this.sidebarLinksList.appendChild(l);
					}
				}
			}
		}

		_closeSettingsModal() {
			if (this._settingsDocClickHandler) {
				document.removeEventListener('click', this._settingsDocClickHandler);
				this._settingsDocClickHandler = null;
			}
			if (this.settingsModal) {
				this.settingsModal.remove();
				this.settingsModal = null;
			}
		}

		_closeDashboardModal() {
			if (this._dashboardDocClickHandler) {
				document.removeEventListener('click', this._dashboardDocClickHandler);
				this._dashboardDocClickHandler = null;
			}
			if (this.dashboardModal) {
				this.dashboardModal.remove();
				this.dashboardModal = null;
			}
		}

		_toggleSettingsModal(triggerElement) {
			this._closeDashboardModal();

			if (this.settingsModal) {
				this._closeSettingsModal();
				return;
			}

			const modal = document.createElement('div');
			modal.className = 'cc-settingsModal';

			const header = document.createElement('div');
			header.className = 'cc-settingsModal__header';

			const title = document.createElement('span');
			title.className = 'cc-settingsModal__title';
			title.textContent = 'Settings · My Links';

			const closeBtn = document.createElement('button');
			closeBtn.type = 'button';
			closeBtn.className = 'cc-settingsModal__close';
			closeBtn.textContent = '×';
			closeBtn.addEventListener('click', () => {
				this._closeSettingsModal();
			});

			header.appendChild(title);
			header.appendChild(closeBtn);
			modal.appendChild(header);

			const content = document.createElement('div');
			content.className = 'cc-settingsModal__content';

			const sectionLabel = document.createElement('div');
			sectionLabel.className = 'cc-settingsModal__sectionLabel';
			sectionLabel.textContent = 'Display Links';
			content.appendChild(sectionLabel);

			if (CC.LINKS?.optional) {
				for (const item of CC.LINKS.optional) {
					const row = document.createElement('label');
					row.className = 'cc-settingsModal__checkboxRow';

					const cb = document.createElement('input');
					cb.type = 'checkbox';
					cb.id = `cc-pref-${item.id}`;
					cb.checked = !!this.savedPreferences[item.id];

					const toggleCheck = (e) => {
						e.stopPropagation();
						const nextState = e.target === cb ? cb.checked : !cb.checked;
						cb.checked = nextState;
						const updated = { ...this.savedPreferences, [item.id]: nextState };
						this._savePreferences(updated);
					};

					cb.addEventListener('click', (e) => e.stopPropagation());
					cb.addEventListener('change', toggleCheck);

					const span = document.createElement('span');
					span.textContent = item.label;

					row.appendChild(cb);
					row.appendChild(span);

					// Ensure clicking the label row toggles the input even if default label behavior is intercepted
					row.addEventListener('click', (e) => {
						e.stopPropagation();
						if (e.target !== cb) {
							toggleCheck(e);
						}
					});

					content.appendChild(row);
				}
			}

			modal.appendChild(content);

			const trigger = triggerElement || this.settingsButton;

			this._settingsDocClickHandler = (e) => {
				if (!modal.contains(e.target) && (!trigger || !trigger.contains(e.target))) {
					this._closeSettingsModal();
				}
			};
			setTimeout(() => {
				if (this._settingsDocClickHandler) {
					document.addEventListener('click', this._settingsDocClickHandler);
				}
			}, 0);

			document.body.appendChild(modal);
			this.settingsModal = modal;

			// Position next to whichever trigger was clicked
			if (trigger && document.contains(trigger)) {
				const rect = trigger.getBoundingClientRect();
				const modalWidth = 230;
				const modalHeight = modal.offsetHeight || 160;

				// Check if trigger is inside sidebar or in the left half of the screen
				const isSidebarOrLeft = rect.left < 350;

				let left, top;

				if (isSidebarOrLeft) {
					// Position to the right side of the icon/section
					left = rect.right + 8;
					if (left + modalWidth > window.innerWidth - 10) {
						left = Math.max(10, rect.left - modalWidth - 8);
					}
					// Align vertically with the button center / top
					top = rect.top - 6;
					if (top + modalHeight > window.innerHeight - 10) {
						top = Math.max(10, window.innerHeight - modalHeight - 10);
					}
				} else {
					// Header / top bar: open directly beneath or aligned next to the gear icon
					top = rect.bottom + 6;
					if (top + modalHeight > window.innerHeight && rect.top > modalHeight + 6) {
						top = rect.top - modalHeight - 6;
					}
					left = Math.max(10, Math.min(window.innerWidth - modalWidth - 10, rect.right - modalWidth));
				}

				modal.style.top = `${Math.max(10, top)}px`;
				modal.style.left = `${Math.max(10, left)}px`;
			} else {
				modal.style.top = '60px';
				modal.style.left = '260px';
			}
		}

		_toggleDashboardModal(triggerElement) {
			this._closeSettingsModal();

			if (this.dashboardModal) {
				this._closeDashboardModal();
				return;
			}

			const modal = document.createElement('div');
			modal.className = 'cc-dashboardModal';

			// Header
			const header = document.createElement('div');
			header.className = 'cc-dashboardModal__header';

			const title = document.createElement('span');
			title.className = 'cc-dashboardModal__title';
			title.textContent = 'Claude Usage Insights · Analytics';

			const closeBtn = document.createElement('button');
			closeBtn.type = 'button';
			closeBtn.className = 'cc-dashboardModal__close';
			closeBtn.textContent = '×';
			closeBtn.addEventListener('click', () => {
				this._closeDashboardModal();
			});

			header.appendChild(title);
			header.appendChild(closeBtn);
			modal.appendChild(header);

			// Body Container
			const body = document.createElement('div');
			body.className = 'cc-dashboardModal__body';

			const history = this._loadHistory();

			if (!history || history.length === 0) {
				const empty = document.createElement('div');
				empty.className = 'cc-dashboardModal__empty';
				empty.textContent = 'Still gathering data — check back tomorrow.';
				body.appendChild(empty);
			} else {
				// Top Controls Bar: Model selector & detection
				const modelBar = document.createElement('div');
				modelBar.className = 'cc-dashboardModal__modelBar';

				const modelLabel = document.createElement('span');
				modelLabel.className = 'cc-dashboardModal__modelLabel';
				modelLabel.textContent = 'Pricing Model:';
				modelBar.appendChild(modelLabel);

				const modelSelect = document.createElement('select');
				modelSelect.className = 'cc-dashboardModal__modelSelect';

				const detected = this._detectActiveModel();
				const currentModel = this.selectedModel || detected || CC.PRICING?.defaultModel;

				if (CC.PRICING?.models) {
					for (const [key, conf] of Object.entries(CC.PRICING.models)) {
						const opt = document.createElement('option');
						opt.value = key;
						opt.textContent = `${conf.label} ($${conf.inputPerMillion}/$${conf.outputPerMillion}/M)`;
						if (key === currentModel) opt.selected = true;
						modelSelect.appendChild(opt);
					}
				}

				modelSelect.addEventListener('change', () => {
					this._saveSelectedModel(modelSelect.value);
					// Re-render dashboard modal to refresh stats and chart
					if (this.dashboardModal) {
						this.dashboardModal.remove();
						this.dashboardModal = null;
						this._toggleDashboardModal(triggerElement);
					}
				});

				modelBar.appendChild(modelSelect);
				body.appendChild(modelBar);

				// Summary Stats Grid
				const statsGrid = document.createElement('div');
				statsGrid.className = 'cc-dashboardModal__statsGrid';

				const now = Date.now();
				const startOfToday = new Date(now).setHours(0, 0, 0, 0);
				const last7DaysCutoff = now - 7 * 24 * 60 * 60 * 1000;
				const last30DaysCutoff = now - 30 * 24 * 60 * 60 * 1000;

				const entriesToday = history.filter((h) => h.timestamp >= startOfToday);
				const entries7d = history.filter((h) => h.timestamp >= last7DaysCutoff);
				const entries30d = history.filter((h) => h.timestamp >= last30DaysCutoff);

				// 1. Avg Daily Tokens (last 7 days)
				const days7Map = {};
				entries7d.forEach((e) => {
					if (typeof e.tokenCount === 'number') {
						const dKey = new Date(e.timestamp).toISOString().slice(0, 10);
						days7Map[dKey] = Math.max(days7Map[dKey] || 0, e.tokenCount);
					}
				});
				const tokenValues = Object.values(days7Map);
				const avgDailyTokens = tokenValues.length > 0
					? Math.round(tokenValues.reduce((a, b) => a + b, 0) / tokenValues.length)
					: (this.currentTotalTokens ? Math.round(this.currentTotalTokens) : 0);

				// 2. Cost calculations
				// Today's cost
				let tokensToday = 0;
				if (entriesToday.length > 0) {
					tokensToday = Math.max(...entriesToday.map((e) => e.tokenCount || 0));
				} else if (this.currentTotalTokens) {
					tokensToday = this.currentTotalTokens;
				}
				const costToday = this._calculateCost({
					totalTokens: tokensToday,
					inputTokens: this.currentInputTokens,
					outputTokens: this.currentOutputTokens
				});

				// This week's cost (sum of daily max tokens in 7d or weekly tokens)
				const days7CostSum = Object.values(days7Map).reduce((acc, t) => {
					return acc + this._calculateCost({ totalTokens: t });
				}, 0);
				const costThisWeek = days7CostSum > 0 ? days7CostSum : costToday;

				// Projected Monthly Cost (current week pace * ~4.3 weeks)
				const projectedMonthlyCost = costThisWeek * 4.3;

				// Busiest Day (last 30 days)
				const days30Map = {};
				entries30d.forEach((e) => {
					const dKey = new Date(e.timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
					const score = (typeof e.sessionPercent === 'number' ? e.sessionPercent : 0) +
						(typeof e.tokenCount === 'number' ? e.tokenCount / 1000 : 0);
					if (!days30Map[dKey] || score > days30Map[dKey].score) {
						days30Map[dKey] = {
							score,
							session: e.sessionPercent ?? 0,
							tokens: e.tokenCount ?? 0,
							label: dKey
						};
					}
				});
				let busiestDayLabel = 'N/A';
				let maxScore = -1;
				for (const [key, val] of Object.entries(days30Map)) {
					if (val.score > maxScore) {
						maxScore = val.score;
						busiestDayLabel = key;
					}
				}

				const makeStat = (lbl, val, sub) => {
					const card = document.createElement('div');
					card.className = 'cc-dashboardModal__statCard';
					const labelEl = document.createElement('div');
					labelEl.className = 'cc-dashboardModal__statLabel';
					labelEl.textContent = lbl;
					const valEl = document.createElement('div');
					valEl.className = 'cc-dashboardModal__statValue';
					valEl.textContent = val;
					card.appendChild(labelEl);
					card.appendChild(valEl);
					if (sub) {
						const subEl = document.createElement('div');
						subEl.className = 'cc-dashboardModal__statSub';
						subEl.textContent = sub;
						card.appendChild(subEl);
					}
					return card;
				};

				statsGrid.appendChild(makeStat('Tokens Today', `~${tokensToday.toLocaleString()}`));
				statsGrid.appendChild(makeStat('Avg Daily Tokens', `~${avgDailyTokens.toLocaleString()}`));
				statsGrid.appendChild(makeStat('Cost Today*', `$${costToday < 0.01 && costToday > 0 ? costToday.toFixed(3) : costToday.toFixed(2)}`));
				statsGrid.appendChild(makeStat('Cost This Week*', `$${costThisWeek.toFixed(2)}`));
				statsGrid.appendChild(makeStat('Projected Month*', `$${projectedMonthlyCost.toFixed(2)}`));
				statsGrid.appendChild(makeStat('Busiest Day (30d)', busiestDayLabel));
				body.appendChild(statsGrid);

				// Chart Controls (Toggles)
				const chartControls = document.createElement('div');
				chartControls.className = 'cc-dashboardModal__chartControls';

				const rangeGroup = document.createElement('div');
				rangeGroup.className = 'cc-dashboardModal__btnGroup';

				const btn7d = document.createElement('button');
				btn7d.type = 'button';
				btn7d.className = `cc-dashboardModal__toggleBtn ${this.dashboardDays === 7 ? 'active' : ''}`;
				btn7d.textContent = '7 Days';

				const btn30d = document.createElement('button');
				btn30d.type = 'button';
				btn30d.className = `cc-dashboardModal__toggleBtn ${this.dashboardDays === 30 ? 'active' : ''}`;
				btn30d.textContent = '30 Days';

				btn7d.addEventListener('click', (e) => {
					e.stopPropagation();
					this.dashboardDays = 7;
					btn7d.classList.add('active');
					btn30d.classList.remove('active');
					this._drawDashboardChart(canvas);
				});

				btn30d.addEventListener('click', (e) => {
					e.stopPropagation();
					this.dashboardDays = 30;
					btn30d.classList.add('active');
					btn7d.classList.remove('active');
					this._drawDashboardChart(canvas);
				});

				rangeGroup.appendChild(btn7d);
				rangeGroup.appendChild(btn30d);

				const metricGroup = document.createElement('div');
				metricGroup.className = 'cc-dashboardModal__btnGroup';

				const btnSession = document.createElement('button');
				btnSession.type = 'button';
				btnSession.className = `cc-dashboardModal__toggleBtn ${this.dashboardMetric === 'session' ? 'active' : ''}`;
				btnSession.textContent = 'Session %';

				const btnTokens = document.createElement('button');
				btnTokens.type = 'button';
				btnTokens.className = `cc-dashboardModal__toggleBtn ${this.dashboardMetric === 'tokens' ? 'active' : ''}`;
				btnTokens.textContent = 'Tokens';

				const btnCost = document.createElement('button');
				btnCost.type = 'button';
				btnCost.className = `cc-dashboardModal__toggleBtn ${this.dashboardMetric === 'cost' ? 'active' : ''}`;
				btnCost.textContent = 'Cost ($)';

				const updateMetricButtons = () => {
					btnSession.classList.toggle('active', this.dashboardMetric === 'session');
					btnTokens.classList.toggle('active', this.dashboardMetric === 'tokens');
					btnCost.classList.toggle('active', this.dashboardMetric === 'cost');
				};

				btnSession.addEventListener('click', (e) => {
					e.stopPropagation();
					this.dashboardMetric = 'session';
					updateMetricButtons();
					this._drawDashboardChart(canvas);
				});

				btnTokens.addEventListener('click', (e) => {
					e.stopPropagation();
					this.dashboardMetric = 'tokens';
					updateMetricButtons();
					this._drawDashboardChart(canvas);
				});

				btnCost.addEventListener('click', (e) => {
					e.stopPropagation();
					this.dashboardMetric = 'cost';
					updateMetricButtons();
					this._drawDashboardChart(canvas);
				});

				metricGroup.appendChild(btnSession);
				metricGroup.appendChild(btnTokens);
				metricGroup.appendChild(btnCost);

				chartControls.appendChild(rangeGroup);
				chartControls.appendChild(metricGroup);
				body.appendChild(chartControls);

				// Canvas Chart Container
				const chartContainer = document.createElement('div');
				chartContainer.className = 'cc-dashboardModal__chartContainer';

				const canvas = document.createElement('canvas');
				canvas.className = 'cc-dashboardModal__canvas';
				canvas.width = 340;
				canvas.height = 140;
				chartContainer.appendChild(canvas);
				body.appendChild(chartContainer);

				this._drawDashboardChart(canvas);
			}

			// Export Actions Row
			const exportRow = document.createElement('div');
			exportRow.className = 'cc-dashboardModal__exportRow';

			const exportLabel = document.createElement('span');
			exportLabel.className = 'cc-dashboardModal__exportLabel';
			exportLabel.textContent = 'Export Data:';
			exportRow.appendChild(exportLabel);

			const btnJson = document.createElement('button');
			btnJson.type = 'button';
			btnJson.className = 'cc-dashboardModal__actionBtn';
			btnJson.textContent = '⬇ Download JSON';
			btnJson.addEventListener('click', (e) => {
				e.stopPropagation();
				this._exportHistory('json');
			});

			const btnCsv = document.createElement('button');
			btnCsv.type = 'button';
			btnCsv.className = 'cc-dashboardModal__actionBtn';
			btnCsv.textContent = '⬇ Download CSV';
			btnCsv.addEventListener('click', (e) => {
				e.stopPropagation();
				this._exportHistory('csv');
			});

			exportRow.appendChild(btnJson);
			exportRow.appendChild(btnCsv);
			body.appendChild(exportRow);

			// Disclaimer note
			const disclaimer = document.createElement('div');
			disclaimer.className = 'cc-dashboardModal__disclaimer';
			disclaimer.textContent = '* Estimated using API-equivalent pricing — actual cost may differ if you\'re on a subscription plan.';
			body.appendChild(disclaimer);

			// Clear history row (de-emphasized, placed below primary export actions)
			const clearRow = document.createElement('div');
			clearRow.className = 'cc-dashboardModal__clearRow';

			const clearBtn = document.createElement('button');
			clearBtn.type = 'button';
			clearBtn.className = 'cc-dashboardModal__clearBtn';
			clearBtn.textContent = 'Clear history';

			const confirmSpan = document.createElement('span');
			confirmSpan.className = 'cc-dashboardModal__clearConfirm cc-hidden';

			const promptText = document.createTextNode('Are you sure? ');
			const confirmYes = document.createElement('button');
			confirmYes.type = 'button';
			confirmYes.className = 'cc-dashboardModal__confirmYes';
			confirmYes.textContent = 'Yes, clear';

			const sep = document.createTextNode(' · ');

			const confirmCancel = document.createElement('button');
			confirmCancel.type = 'button';
			confirmCancel.className = 'cc-dashboardModal__confirmCancel';
			confirmCancel.textContent = 'Cancel';

			confirmSpan.appendChild(promptText);
			confirmSpan.appendChild(confirmYes);
			confirmSpan.appendChild(sep);
			confirmSpan.appendChild(confirmCancel);

			clearBtn.addEventListener('click', (e) => {
				e.stopPropagation();
				clearBtn.classList.add('cc-hidden');
				confirmSpan.classList.remove('cc-hidden');
			});

			confirmCancel.addEventListener('click', (e) => {
				e.stopPropagation();
				confirmSpan.classList.add('cc-hidden');
				clearBtn.classList.remove('cc-hidden');
			});

			confirmYes.addEventListener('click', (e) => {
				e.stopPropagation();
				this._clearUsageHistory();
				// Immediately re-render dashboard modal in place to show empty state
				if (this.dashboardModal) {
					this.dashboardModal.remove();
					this.dashboardModal = null;
					this._toggleDashboardModal(triggerElement);
				}
			});

			clearRow.appendChild(clearBtn);
			clearRow.appendChild(confirmSpan);
			body.appendChild(clearRow);

			// Footer with permanent YouTube link
			const footer = document.createElement('div');
			footer.className = 'cc-dashboardModal__footer';

			const ytLink = document.createElement('a');
			ytLink.href = CC.LINKS?.permanent?.url || 'https://www.youtube.com/@ArtificialPopcorn?sub_confirmation=1';
			ytLink.target = '_blank';
			ytLink.rel = 'noopener noreferrer';
			ytLink.className = 'cc-link cc-link--permanent';
			ytLink.textContent = '📺 Watch Artificial Popcorn on YouTube';

			footer.appendChild(ytLink);
			modal.appendChild(body);
			modal.appendChild(footer);

			const trigger = triggerElement || this.dashboardButton;

			this._dashboardDocClickHandler = (e) => {
				if (!modal.contains(e.target) && (!trigger || !trigger.contains(e.target))) {
					this._closeDashboardModal();
				}
			};
			setTimeout(() => {
				if (this._dashboardDocClickHandler) {
					document.addEventListener('click', this._dashboardDocClickHandler);
				}
			}, 0);

			document.body.appendChild(modal);
			this.dashboardModal = modal;

			// Position next to whichever trigger was clicked
			if (trigger && document.contains(trigger)) {
				const rect = trigger.getBoundingClientRect();
				const modalWidth = 380;
				const modalHeight = modal.offsetHeight || 440;

				const isSidebarOrLeft = rect.left < 350;

				let left, top;

				if (isSidebarOrLeft) {
					// Position to the right side of the icon/section
					left = rect.right + 8;
					if (left + modalWidth > window.innerWidth - 10) {
						left = Math.max(10, rect.left - modalWidth - 8);
					}
					top = rect.top - 20;
					if (top + modalHeight > window.innerHeight - 10) {
						top = Math.max(10, window.innerHeight - modalHeight - 10);
					}
				} else {
					top = rect.bottom + 6;
					if (top + modalHeight > window.innerHeight && rect.top > modalHeight + 6) {
						top = Math.max(10, rect.top - modalHeight - 6);
					}
					left = Math.max(10, Math.min(window.innerWidth - modalWidth - 10, rect.right - modalWidth));
				}

				modal.style.top = `${Math.max(10, top)}px`;
				modal.style.left = `${Math.max(10, left)}px`;
			} else {
				modal.style.top = '60px';
				modal.style.left = '260px';
			}
		}

		_drawDashboardChart(canvas) {
			if (!canvas) return;
			const ctx = canvas.getContext('2d');
			if (!ctx) return;

			const width = canvas.width;
			const height = canvas.height;
			ctx.clearRect(0, 0, width, height);

			const history = this._loadHistory();
			const now = Date.now();
			const days = this.dashboardDays || 7;
			const cutoff = now - days * 24 * 60 * 60 * 1000;
			const entries = history.filter((h) => h.timestamp >= cutoff);

			const isDark = document.documentElement.dataset?.mode === 'dark';
			const gridColor = isDark ? 'rgba(255, 255, 255, 0.08)' : 'rgba(0, 0, 0, 0.06)';
			const textColor = isDark ? 'rgba(255, 255, 255, 0.5)' : 'rgba(0, 0, 0, 0.45)';

			let lineColor = '#5aa6ff';
			let areaColor = isDark ? 'rgba(90, 166, 255, 0.15)' : 'rgba(90, 166, 255, 0.1)';

			if (this.dashboardMetric === 'cost') {
				lineColor = '#10b981'; // Green for cost
				areaColor = isDark ? 'rgba(16, 185, 129, 0.18)' : 'rgba(16, 185, 129, 0.12)';
			} else if (this.dashboardMetric === 'session') {
				lineColor = '#ce2029'; // Red for session limit
				areaColor = isDark ? 'rgba(206, 32, 41, 0.15)' : 'rgba(206, 32, 41, 0.1)';
			}

			const padL = 38;
			const padR = 12;
			const padT = 12;
			const padB = 22;
			const plotW = width - padL - padR;
			const plotH = height - padT - padB;

			// Draw grid & axes
			ctx.strokeStyle = gridColor;
			ctx.lineWidth = 1;
			ctx.beginPath();
			for (let i = 0; i <= 3; i++) {
				const y = padT + (plotH / 3) * i;
				ctx.moveTo(padL, y);
				ctx.lineTo(width - padR, y);
			}
			ctx.stroke();

			if (entries.length === 0) {
				ctx.fillStyle = textColor;
				ctx.font = '11px sans-serif';
				ctx.textAlign = 'center';
				ctx.fillText('No activity recorded in this period', width / 2, height / 2);
				return;
			}

			// Extract data points
			const isTokens = this.dashboardMetric === 'tokens';
			const isCost = this.dashboardMetric === 'cost';

			const points = entries.map((e) => {
				let val = 0;
				if (isCost) {
					val = this._calculateCost({
						totalTokens: e.tokenCount ?? 0,
						inputTokens: e.inputTokens,
						outputTokens: e.outputTokens
					});
				} else if (isTokens) {
					val = typeof e.tokenCount === 'number' ? e.tokenCount : 0;
				} else {
					val = typeof e.sessionPercent === 'number' ? e.sessionPercent : 0;
				}
				return { t: e.timestamp, v: val };
			});

			let maxVal = 100;
			if (isCost) {
				const maxPoint = Math.max(...points.map((p) => p.v), 0.1);
				maxVal = maxPoint < 1 ? Math.ceil(maxPoint * 10) / 10 : Math.ceil(maxPoint);
			} else if (isTokens) {
				maxVal = Math.max(...points.map((p) => p.v), 1000);
				maxVal = Math.ceil(maxVal / 1000) * 1000;
			}

			// Y-Axis Labels
			ctx.fillStyle = textColor;
			ctx.font = '9px sans-serif';
			ctx.textAlign = 'right';

			if (isCost) {
				ctx.fillText(`$${maxVal.toFixed(maxVal < 1 ? 2 : 1)}`, padL - 4, padT + 8);
				ctx.fillText(`$${(maxVal / 2).toFixed(maxVal < 1 ? 2 : 1)}`, padL - 4, padT + plotH / 2 + 3);
			} else if (isTokens) {
				ctx.fillText(`${Math.round(maxVal / 1000)}k`, padL - 4, padT + 8);
				ctx.fillText(`${Math.round(maxVal / 2000)}k`, padL - 4, padT + plotH / 2 + 3);
			} else {
				ctx.fillText(`${maxVal}%`, padL - 4, padT + 8);
				ctx.fillText(`${Math.round(maxVal / 2)}%`, padL - 4, padT + plotH / 2 + 3);
			}
			ctx.fillText('0', padL - 4, padT + plotH);

			// X-Axis Labels (Date bounds)
			ctx.textAlign = 'left';
			const startD = new Date(cutoff).toLocaleDateString(undefined, { month: 'numeric', day: 'numeric' });
			const endD = new Date(now).toLocaleDateString(undefined, { month: 'numeric', day: 'numeric' });
			ctx.fillText(startD, padL, height - 6);
			ctx.textAlign = 'right';
			ctx.fillText(endD, width - padR, height - 6);

			// Calculate canvas coords
			const coords = points.map((p) => {
				const tRatio = Math.max(0, Math.min(1, (p.t - cutoff) / (now - cutoff)));
				const vRatio = Math.max(0, Math.min(1, p.v / (maxVal || 1)));
				const x = padL + tRatio * plotW;
				const y = padT + plotH - vRatio * plotH;
				return { x, y };
			});

			// Fill Area
			ctx.fillStyle = areaColor;
			ctx.beginPath();
			ctx.moveTo(coords[0].x, padT + plotH);
			coords.forEach((c) => ctx.lineTo(c.x, c.y));
			ctx.lineTo(coords[coords.length - 1].x, padT + plotH);
			ctx.closePath();
			ctx.fill();

			// Draw Line
			ctx.strokeStyle = lineColor;
			ctx.lineWidth = 2;
			ctx.beginPath();
			coords.forEach((c, idx) => {
				if (idx === 0) ctx.moveTo(c.x, c.y);
				else ctx.lineTo(c.x, c.y);
			});
			ctx.stroke();

			// Draw Points
			ctx.fillStyle = lineColor;
			coords.forEach((c) => {
				ctx.beginPath();
				ctx.arc(c.x, c.y, 2.5, 0, Math.PI * 2);
				ctx.fill();
			});
		}

		_exportHistory(format = 'json') {
			const history = this._loadHistory();
			const dateStr = new Date().toISOString().slice(0, 10);
			let content = '';
			let mimeType = 'text/plain';
			let fileName = `claude-usage-history-${dateStr}`;

			if (format === 'csv') {
				mimeType = 'text/csv';
				fileName += '.csv';
				const headers = [
					'Timestamp',
					'ISO_Date',
					'SessionPercent',
					'WeeklyPercent',
					'TokenCount',
					'InputTokens',
					'OutputTokens',
					'EstimatedCostUSD'
				];
				const rows = history.map((h) => {
					const estCost = this._calculateCost({
						totalTokens: h.tokenCount ?? 0,
						inputTokens: h.inputTokens,
						outputTokens: h.outputTokens
					});
					return [
						h.timestamp,
						new Date(h.timestamp).toISOString(),
						h.sessionPercent ?? '',
						h.weeklyPercent ?? '',
						h.tokenCount ?? '',
						h.inputTokens ?? '',
						h.outputTokens ?? '',
						estCost.toFixed(4)
					];
				});
				content = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
			} else {
				mimeType = 'application/json';
				fileName += '.json';
				const enriched = history.map((h) => ({
					...h,
					estimatedCostUSD: Number(
						this._calculateCost({
							totalTokens: h.tokenCount ?? 0,
							inputTokens: h.inputTokens,
							outputTokens: h.outputTokens
						}).toFixed(4)
					)
				}));
				content = JSON.stringify(enriched, null, 2);
			}

			const blob = new Blob([content], { type: mimeType });
			const url = URL.createObjectURL(blob);
			const a = document.createElement('a');
			a.href = url;
			a.download = fileName;
			document.body.appendChild(a);
			a.click();
			document.body.removeChild(a);
			URL.revokeObjectURL(url);
		}

		_observeTheme() {
			// Watch for theme changes (data-mode attribute on <html>)
			const observer = new MutationObserver(() => this.refreshProgressChrome());
			observer.observe(document.documentElement, { attributes: true, attributeFilter: ['data-mode'] });
		}

		_observeDom() {
			// Track pending reattach attempts independently
			let headerReattachPending = false;
			let sidebarReattachPending = false;

			this.domObserver = new MutationObserver(() => {
				const headerMissing = !document.contains(this.headerContainer);
				const sidebarMissing = this.sidebarSection && !document.contains(this.sidebarSection);

				if (headerMissing && !headerReattachPending) {
					headerReattachPending = true;
					CC.waitForElement(CC.DOM.CHAT_MENU_TRIGGER, 60000).then((el) => {
						headerReattachPending = false;
						if (el) this.attachHeader();
					});
				}

				if (sidebarMissing && !sidebarReattachPending) {
					sidebarReattachPending = true;
					CC.waitForElement(CC.DOM.SIDEBAR_CONTAINER, 60000).then((el) => {
						sidebarReattachPending = false;
						if (el) this.attachSidebar();
					});
				}
			});
			this.domObserver.observe(document.body, { childList: true, subtree: true });
		}

		_setupTooltips() {
			this.lengthTooltip = makeTooltip(
				"Approximate tokens (excludes system prompt).\nUses a generic tokenizer, may differ from Claude's count.\nBecomes invalid after context compaction.\nBar scale: 200k tokens (Claude's maximum context length, will compact before then)."
			);
			setupTooltip(
				this.lengthGroup,
				this.lengthTooltip,
				{ topOffset: 8 }
			);

			setupTooltip(
				this.cachedDisplay,
				makeTooltip("Messages sent while cached are significantly cheaper."),
				{ topOffset: 8 }
			);
		}

		attach() {
			this.attachSidebar();
			this.attachHeader();
			this.refreshProgressChrome();
		}

		attachSidebar() {
			if (!this.sidebarSection) return;
			// Find sidebar container
			const sidebar = document.querySelector('nav[aria-label*="sidebar" i], [data-testid="sidebar"], nav, aside');
			if (!sidebar) return;

			// Helper to find an element matching text within sidebar
			const findElementByText = (root, tag, textRegex) => {
				const elements = root.querySelectorAll(tag);
				for (const el of elements) {
					if (textRegex.test(el.textContent?.trim() || '')) {
						return el;
					}
				}
				return null;
			};

			// 1. Look for Customize button (or its container)
			const customizeEl =
				sidebar.querySelector('a[href*="/settings"], a[href*="/customize"], button[aria-label*="Customize" i]') ||
				findElementByText(sidebar, 'a, button, div', /^Customize\s*Claude|^Customize/i);

			// 2. Look for Chats / Recents / Tasks section heading or container
			const chatsSectionHeading =
				findElementByText(sidebar, 'h2, h3, div, span, button', /^Chats|^Recent chats|^Recents|^Tasks/i);

			let insertionTarget = null;
			let insertBefore = false;

			if (customizeEl) {
				// We want it after Customize button (or its list row container)
				// Find direct child of sidebar or the nav item container containing customizeEl
				let cur = customizeEl;
				while (cur && cur.parentElement && cur.parentElement !== sidebar && !cur.parentElement.classList.contains('flex-col')) {
					cur = cur.parentElement;
				}
				insertionTarget = cur;
				insertBefore = false; // insert after customize
			} else if (chatsSectionHeading) {
				// Fallback: insert before Chats section
				let cur = chatsSectionHeading;
				while (cur && cur.parentElement && cur.parentElement !== sidebar && !cur.parentElement.classList.contains('flex-col')) {
					cur = cur.parentElement;
				}
				insertionTarget = cur;
				insertBefore = true; // insert before chats
			}

			if (insertionTarget && insertionTarget.parentElement) {
				const parent = insertionTarget.parentElement;
				if (insertBefore) {
					if (this.sidebarSection.nextElementSibling !== insertionTarget) {
						parent.insertBefore(this.sidebarSection, insertionTarget);
					}
				} else {
					if (insertionTarget.nextElementSibling !== this.sidebarSection) {
						insertionTarget.after(this.sidebarSection);
					}
				}
				return;
			}

			// Fallback if neither element is found
			if (!sidebar.contains(this.sidebarSection)) {
				const bottomGroup =
					sidebar.querySelector('[data-testid="user-menu-button"]')?.closest('div') ||
					sidebar.querySelector('.mt-auto') ||
					sidebar.querySelector('div:last-child');

				if (bottomGroup && bottomGroup.parentElement === sidebar) {
					sidebar.insertBefore(this.sidebarSection, bottomGroup);
				} else {
					sidebar.appendChild(this.sidebarSection);
				}
			}
		}

		attachHeader() {
			const chatMenu = document.querySelector(CC.DOM.CHAT_MENU_TRIGGER);
			if (!chatMenu) return;
			const anchor = chatMenu.closest(CC.DOM.CHAT_PROJECT_WRAPPER) || chatMenu.parentElement;
			if (!anchor) return;

			if (anchor.nextElementSibling !== this.headerContainer) {
				anchor.after(this.headerContainer);
			}
			this._renderHeader();
			this.refreshProgressChrome();
		}


		setPendingCache(pending) {
			this.pendingCache = pending;
			if (this.cacheTimeSpan) {
				if (pending) {
					this.cacheTimeSpan.style.color = '';
				} else {
					const { boldColor } = this.getProgressChrome();
					this.cacheTimeSpan.style.color = boldColor;
				}
			}
		}

		setConversationMetrics({ totalTokens, inputTokens, outputTokens, cachedUntil } = {}) {
			this.pendingCache = false;

			if (typeof totalTokens !== 'number') {
				this.lengthDisplay.textContent = '';
				this.cachedDisplay.textContent = '';
				this.lastCachedUntilMs = null;
				this._renderHeader();
				return;
			}

			if (typeof inputTokens === 'number') this.currentInputTokens = inputTokens;
			if (typeof outputTokens === 'number') this.currentOutputTokens = outputTokens;

			const pct = Math.max(0, Math.min(100, (totalTokens / CC.CONST.CONTEXT_LIMIT_TOKENS) * 100));
			this.lengthDisplay.textContent = `~${totalTokens.toLocaleString()} tokens`;

			// Mini bar (hide when full - context is definitely compacted by then)
			const isFull = pct >= 99.5;
			if (isFull) {
				this.lengthDisplay.style.opacity = '0.5';
				this.lengthBar = null;
				this.lengthGroup.replaceChildren(this.lengthDisplay);
				if (this.lengthTooltip) {
					this.lengthTooltip.textContent =
						"Approximate tokens (excludes system prompt).\nUses a generic tokenizer, may differ from Claude's count.\nThis count is invalid after compaction.";
				}
			} else {
				this.lengthDisplay.style.opacity = '';
				const bar = document.createElement('div');
				bar.className = 'cc-bar cc-bar--mini';
				this.lengthBar = bar;
				const fill = document.createElement('div');
				fill.className = 'cc-bar__fill';
				fill.style.width = `${pct}%`;
				bar.appendChild(fill);
				this.refreshProgressChrome();

				const barContainer = document.createElement('span');
				barContainer.className = 'inline-flex items-center';
				barContainer.appendChild(bar);

				this.lengthGroup.replaceChildren(this.lengthDisplay, document.createTextNode('\u00A0\u00A0'), barContainer);
			}

			// Cache timer
			const now = Date.now();
			if (typeof cachedUntil === 'number' && cachedUntil > now) {
				this.lastCachedUntilMs = cachedUntil;
				const secondsLeft = Math.max(0, Math.ceil((cachedUntil - now) / 1000));
				const { boldColor } = this.getProgressChrome();
				this.cacheTimeSpan = Object.assign(document.createElement('span'), {
					className: 'cc-cacheTime',
					textContent: formatSeconds(secondsLeft)
				});
				this.cacheTimeSpan.style.color = boldColor;
				this.cachedDisplay.replaceChildren(document.createTextNode('cached for\u00A0'), this.cacheTimeSpan);
			} else {
				this.lastCachedUntilMs = null;
				this.cacheTimeSpan = null;
				this.cachedDisplay.textContent = '';
			}

			if (typeof totalTokens === 'number') {
				this.recordSnapshot({
					tokenCount: totalTokens,
					inputTokens: this.currentInputTokens,
					outputTokens: this.currentOutputTokens
				});
			}

			this._renderHeader();
		}

		_renderHeader() {
			this.headerContainer.replaceChildren();

			const hasTokens = !!this.lengthDisplay.textContent;
			const hasCache = !!this.cachedDisplay.textContent;

			if (hasTokens) {
				if (hasCache) {
					const gap = this.lengthBar ? '\u00A0\u00A0' : '\u00A0';
					this.headerDisplay.replaceChildren(
						this.lengthGroup,
						document.createTextNode(gap),
						this.cachedDisplay
					);
				} else {
					this.headerDisplay.replaceChildren(this.lengthGroup);
				}
				this.headerContainer.appendChild(this.headerDisplay);
			}

			// Append links container (YouTube + optional + settings + dashboard)
			if (this.linksContainer) {
				if (hasTokens) {
					const sep = document.createElement('span');
					sep.className = 'cc-headerSep';
					sep.textContent = '·';
					this.headerContainer.appendChild(sep);
				}
				this.headerContainer.appendChild(this.linksContainer);
			}

			// Check and show first-run welcome tooltip if not seen yet
			this._showWelcomeTooltipIfNeeded();
		}

		_showWelcomeTooltipIfNeeded() {
			if (!this.permanentLink) return;
			try {
				const seen = localStorage.getItem(CC.CONST.SEEN_WELCOME_TOOLTIP_KEY);
				if (seen) return;
			} catch {
				return;
			}

			if (this.welcomeTooltipEl) return;

			// Create welcome tooltip element
			const tooltip = document.createElement('div');
			tooltip.className = 'cc-welcomeTooltip';

			const textSpan = document.createElement('span');
			textSpan.className = 'cc-welcomeTooltip__text';
			textSpan.textContent = '👋 New here? Check out my AI PM series';

			const dismissBtn = document.createElement('button');
			dismissBtn.type = 'button';
			dismissBtn.className = 'cc-welcomeTooltip__close';
			dismissBtn.setAttribute('aria-label', 'Dismiss');
			dismissBtn.innerHTML = '&times;';

			tooltip.appendChild(textSpan);
			tooltip.appendChild(dismissBtn);

			const dismiss = () => {
				try {
					localStorage.setItem(CC.CONST.SEEN_WELCOME_TOOLTIP_KEY, 'true');
				} catch {
					// ignore
				}
				if (this.welcomeTooltipEl) {
					this.welcomeTooltipEl.remove();
					this.welcomeTooltipEl = null;
				}
				if (this.welcomeTooltipTimer) {
					clearTimeout(this.welcomeTooltipTimer);
					this.welcomeTooltipTimer = null;
				}
				window.removeEventListener('resize', positionTooltip);
				window.removeEventListener('scroll', positionTooltip);
			};

			dismissBtn.addEventListener('click', (e) => {
				e.preventDefault();
				e.stopPropagation();
				dismiss();
			});

			this.welcomeTooltipEl = tooltip;
			document.body.appendChild(tooltip);

			const positionTooltip = () => {
				if (!this.welcomeTooltipEl || !this.permanentLink || !document.contains(this.permanentLink)) return;
				const rect = this.permanentLink.getBoundingClientRect();
				const tipRect = this.welcomeTooltipEl.getBoundingClientRect();

				const left = Math.max(10, Math.min(window.innerWidth - tipRect.width - 10, rect.left + rect.width / 2 - tipRect.width / 2));
				const top = rect.bottom + 8;

				this.welcomeTooltipEl.style.top = `${top}px`;
				this.welcomeTooltipEl.style.left = `${left}px`;
			};

			// Position initially and attach listeners
			setTimeout(() => {
				positionTooltip();
				if (this.welcomeTooltipEl) {
					this.welcomeTooltipEl.classList.add('cc-welcomeTooltip--visible');
				}
			}, 50);

			window.addEventListener('resize', positionTooltip);
			window.addEventListener('scroll', positionTooltip);

			// Auto dismiss after ~8 seconds
			this.welcomeTooltipTimer = setTimeout(() => {
				dismiss();
			}, 8000);
		}

		setUsage(usage) {
			this.refreshProgressChrome();
			const session = usage?.five_hour || null;
			const weekly = usage?.seven_day || null;

			if (session && typeof session.utilization === 'number') {
				const rawPct = session.utilization;
				const pct = Math.round(rawPct * 10) / 10;
				this.sessionResetMs = session.resets_at ? Date.parse(session.resets_at) : null;
				this.sessionWindowStartMs = this.sessionResetMs ? this.sessionResetMs - 5 * 60 * 60 * 1000 : null;
				const resetText = this.sessionResetMs ? formatResetCountdown(this.sessionResetMs) : '';

				const width = Math.max(0, Math.min(100, rawPct));

				// Update sidebar session bar
				if (this.sidebarSessionStat) {
					this.sidebarSessionStat.textContent = `${pct}%${resetText ? ` (${resetText})` : ''}`;
				}
				if (this.sidebarSessionBarFill) {
					this.sidebarSessionBarFill.style.width = `${width}%`;
					this.sidebarSessionBarFill.classList.toggle('cc-full', width >= 99.5);
				}
			} else {
				this.sessionResetMs = null;
				this.sessionWindowStartMs = null;
				if (this.sidebarSessionStat) this.sidebarSessionStat.textContent = '0%';
				if (this.sidebarSessionBarFill) this.sidebarSessionBarFill.style.width = '0%';
			}

			if (weekly && typeof weekly.utilization === 'number') {
				const rawPct = weekly.utilization;
				const pct = Math.round(rawPct * 10) / 10;
				this.weeklyResetMs = weekly.resets_at ? Date.parse(weekly.resets_at) : null;
				this.weeklyWindowStartMs = this.weeklyResetMs ? this.weeklyResetMs - 7 * 24 * 60 * 60 * 1000 : null;
				const resetText = this.weeklyResetMs ? formatResetCountdown(this.weeklyResetMs) : '';

				const width = Math.max(0, Math.min(100, rawPct));

				// Update sidebar weekly bar
				if (this.sidebarWeeklyStat) {
					this.sidebarWeeklyStat.textContent = `${pct}%${resetText ? ` (${resetText})` : ''}`;
				}
				if (this.sidebarWeeklyBarFill) {
					this.sidebarWeeklyBarFill.style.width = `${width}%`;
					this.sidebarWeeklyBarFill.classList.toggle('cc-full', width >= 99.5);
				}
			} else {
				this.weeklyResetMs = null;
				this.weeklyWindowStartMs = null;
				if (this.sidebarWeeklyStat) this.sidebarWeeklyStat.textContent = '0%';
				if (this.sidebarWeeklyBarFill) this.sidebarWeeklyBarFill.style.width = '0%';
			}

			const sPct = session && typeof session.utilization === 'number' ? session.utilization : null;
			const wPct = weekly && typeof weekly.utilization === 'number' ? weekly.utilization : null;
			if (sPct !== null || wPct !== null) {
				this.recordSnapshot({
					sessionPercent: sPct,
					weeklyPercent: wPct
				});
			}
		}

		tick() {
			// Cache countdown
			const now = Date.now();
			if (this.lastCachedUntilMs && this.lastCachedUntilMs > now) {
				const secondsLeft = Math.max(0, Math.ceil((this.lastCachedUntilMs - now) / 1000));
				if (this.cacheTimeSpan) {
					this.cacheTimeSpan.textContent = formatSeconds(secondsLeft);
				}
			} else if (this.lastCachedUntilMs && this.lastCachedUntilMs <= now) {
				this.lastCachedUntilMs = null;
				this.cacheTimeSpan = null;
				this.pendingCache = false;
				this.cachedDisplay.textContent = '';
				this._renderHeader();
			}

			// Reset countdown text for sidebar metrics
			if (this.sessionResetMs && this.sidebarSessionStat && this.currentSessionPercent != null) {
				const pct = Math.round(this.currentSessionPercent * 10) / 10;
				this.sidebarSessionStat.textContent = `${pct}% (${formatResetCountdown(this.sessionResetMs)})`;
			}

			if (this.weeklyResetMs && this.sidebarWeeklyStat && this.currentWeeklyPercent != null) {
				const pct = Math.round(this.currentWeeklyPercent * 10) / 10;
				this.sidebarWeeklyStat.textContent = `${pct}% (${formatResetCountdown(this.weeklyResetMs)})`;
			}
		}
	}

	CC.ui = {
		CounterUI
	};
})();

// Creator: Tushar Vishwakarma
