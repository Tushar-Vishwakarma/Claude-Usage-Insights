# Claude Usage Insights

A customized browser extension and analytics toolkit for [Claude.ai](https://claude.ai) created and maintained by **Tushar Vishwakarma**. Based on the open-source [Claude Counter](https://github.com/lucas-cantor/claude-counter) project.

---

## Features

- **Token Counter & Context Progress** — Real-time approximate token count for current conversation trunk with a progress bar scaled to Claude's 200k context window.
- **Cache Timer** — 5-minute ephemeral prompt caching countdown showing how long prompt cache remains active.
- **Session & Weekly Usage Limits** — Clean sidebar progress bars with live 5-hour session and 7-day weekly rate limit utilization and rollover countdowns, positioned directly between the Customize button and Chats & Tasks.
- **Usage Analytics Dashboard** — 6-card summary grid (Tokens Today, Avg Daily Tokens, Cost Today*, Cost This Week*, Projected Month*, Busiest Day), canvas trend charts (7-day / 30-day view for Session %, Tokens, or Cost in USD), and one-click JSON/CSV data export.
- **Cost Estimation & Model Selection** — API-equivalent cost estimations with customizable model selection (Claude 3.7 Sonnet, 3.5 Sonnet, 3.5 Haiku, 3 Opus) and model auto-detection.
- **Custom Sidebar & Settings** — Collapsible "Usage" section matching Claude's native UI, direct link to Artificial Popcorn YouTube channel, configurable optional links (LinkedIn, Topmate, Books), and first-run guidance.

---

## Installation & Local Development

### Chrome / Brave / Edge / Chromium
1. Open `chrome://extensions` (or `edge://extensions` / `brave://extensions`).
2. Enable **Developer mode** toggle in the top-right corner.
3. Click **Load unpacked** and select the `claude-counter-custom/` directory.
4. Navigate to [claude.ai](https://claude.ai) to see the counter and dashboard widgets.

### Firefox
1. Open `about:debugging#/runtime/this-firefox`.
2. Click **Load Temporary Add-on...**.
3. Select `manifest.json` inside the `claude-counter-custom/` folder.

---

## How It Works

- Intercepts Claude's API responses locally to read conversation trunk data and usage metrics.
- Uses a local vendored tokenizer (`o200k_base`) for token calculation.
- Syncs with Claude's `/usage` and SSE `message_limit` stream for utilization metrics.
- Persists usage history and custom preferences locally in `localStorage`.

---

## Privacy

- **100% Local**: All analytics, token metrics, and preferences remain inside your browser.
- **No Remote Telemetry**: No third-party servers or external tracking endpoints are contacted.
- Requests are strictly limited to `https://claude.ai/*`.

---

## Credits & Attribution

- Built upon the open-source **Claude Counter** project (MIT License).
- Token counting tokenizer powered by `gpt-tokenizer` (MIT License) — see `THIRD_PARTY_NOTICES.md`.

---

## License

MIT License — see `LICENSE` for details.

<!-- Creator: Tushar Vishwakarma -->
